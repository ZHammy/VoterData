<?php

/*
 * Init Direct Classes Here
 */
(new \FluentSnippets\App\Hooks\Handlers\AdminMenuHandler())->register();
(new \FluentSnippets\App\Hooks\Handlers\CodeHandler())->register();

<?php
/**
 * The main template file for the custom WordPress theme.
 *
 * This file is used to display content when no other template files are available.
 *
 * @package CustomWordPressTheme
 */

get_header(); ?>

<div class="container">

</div>

<?php get_footer(); ?>
<?php
get_header(); ?>

<div class="container">
    <h1>Searchable and Filterable Table</h1>
    <?php include locate_template('templates/searchable-table.php'); ?>
</div>

<?php
get_footer();